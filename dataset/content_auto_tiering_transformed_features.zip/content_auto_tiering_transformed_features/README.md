# Content Auto-Tiering — Canonical Transformed Features

Prepared 2026-09-14 for internal sharing.

## Contents

- `legacy_paid/`: Option 2 transformed features for 467 legacy journeys and 379 PAID journeys, their 846-row merged asset table, chunk tables, frozen splits, and data-generation reports.
- `wave2_research/`: the registered 84-feature Wave-2 asset pool and ordered selected-21 feature contract.
- `exact_nonpaid_1197/`: the final leakage-safe 1,197 × 21 exact/non-PAID model-ready matrix, cohort/coverage manifests, lineage, and integrity locks.
- `DATA_DICTIONARY.csv`: dataset-column inventory with inferred roles.
- `MANIFEST.csv` and `SHA256SUMS.txt`: row/column counts, source lineage, transformations, and checksums.

## Important semantics

- Legacy rows use the approved `partial_tier_a_hybrid` feature path.
- PAID rows use full production feature semantics and manually reviewed `Assigned Tier` labels.
- The 846-row Option 2 merged table combines those two feature provenances; preserve the `cohort` and `feature_source` fields.
- The final 1,197-row exact/non-PAID matrix uses BQ-tier labels and has zero eligible-PAID and frozen-validation overlap.
- All train/validation splitting is at `journey_id` level.

